import '@fontsource/lora';
import styled from 'styled-components';

import Headline from '../features/dashboard/Headline';
import Goods from '../features/dashboard/Goods';
import About from '../features/dashboard/About';
import DashStats from '../features/dashboard/DashStats';

const StyledDashboard = styled.div`
  width: 100%;
  min-height: 100%;
  display: flex;
  flex-direction: column;
  background-color: var(--brand-cream);
  font-family: var(--font-display);
  overflow-x: hidden;
`;

function Dashboard() {
  return (
    <StyledDashboard>
      <Headline />
      <DashStats />
      <Goods />
      <About />
    </StyledDashboard>
  );
}

export default Dashboard;
