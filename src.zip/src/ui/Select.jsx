import styled from 'styled-components';
import { format } from 'date-fns';
import { sr } from 'date-fns/locale/sr';

const StyledSelect = styled.select`
  font-size: 1.4rem;
  padding: 0.8rem 1.2rem;
  border: 1px solid
    ${(props) =>
      props.type === 'white'
        ? 'var(--color-grey-100)'
        : 'var(--color-grey-300)'};
  border-radius: var(--border-radius-sm);
  background-color: var(--color-grey-0);
  font-weight: 500;
  box-shadow: var(--shadow-sm);
`;
function Select({ options, value, onChange, ...props }) {
  return (
    <StyledSelect value={value} onChange={onChange} {...props}>
      {options?.map((option) => (
        <option key={option.value} value={option.value}>
          {option.value}: {format(option.label, 'dd MMM yyyy', { locale: sr })}
        </option>
      ))}
    </StyledSelect>
  );
}

export default Select;
